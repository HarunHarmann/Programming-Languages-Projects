

public class Main {

	public static void main(String[] args) {
		
		if (args[0].equals("gameGrid.txt") && args[1].equals("command.txt")) {
			 Command command = new Command();
			 command.command();
		}
		
		
		
	}

}
