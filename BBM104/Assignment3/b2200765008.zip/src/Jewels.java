import java.util.ArrayList;

public class Jewels {
	private int point =0;

	public int getPoint() {
		return point;
	}

	public void setPoint(int point) {
		this.point += point;
	}

	public void findKind(int row, int col, ArrayList<ArrayList<String>> gameGrid, String jewelString) {
		// TODO Auto-generated method stub
		
	}
	
	
}
