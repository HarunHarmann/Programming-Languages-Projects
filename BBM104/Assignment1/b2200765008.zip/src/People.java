
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;





public class People {
	public ArrayList<String> listAllPerson() {
		ArrayList<String> listOfPeople = new ArrayList<>();
		
		
		try {
		BufferedReader people1 = new BufferedReader(new FileReader("people.txt"));
			int totalLines = 0;
			while (people1.readLine() != null)
				totalLines++;
			people1.close();
			
			BufferedReader people2 = new BufferedReader(new FileReader("people.txt"));
			
			if (totalLines <100){
			 for (int i = 0; i < totalLines; i++) {
				String currentLine = people2.readLine();
				
				String[] addThisTo =currentLine.split("\t");
				for (String j:addThisTo) {
					listOfPeople.add(j);
				}				
			 }			
			}			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return listOfPeople;
	}	
}